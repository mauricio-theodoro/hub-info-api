package br.com.hubinfo.audit;

public class AuditorAwareImpl {
}
