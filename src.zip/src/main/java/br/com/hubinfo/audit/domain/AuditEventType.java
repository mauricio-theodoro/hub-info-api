package br.com.hubinfo.audit.domain;

public enum AuditEventType {
    USER_CREATED,
    AUTH_LOGIN_SUCCESS,
    AUTH_LOGIN_FAILURE,

    // Base pronta para serviços (Commit futuro: CND etc.)
    SERVICE_REQUESTED,
    SERVICE_REQUEST_SUCCESS,
    SERVICE_REQUEST_CREATED, SERVICE_REQUEST_FAILURE,

    // === CAPTCHA (Commit 15) ===
    CAPTCHA_CHALLENGE_CREATED,
    CAPTCHA_CHALLENGE_SOLVED
}
