package br.com.hubinfo.config;

public class JpaAuditingConfig {
}
