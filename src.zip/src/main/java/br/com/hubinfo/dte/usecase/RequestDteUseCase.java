package br.com.hubinfo.dte.usecase;

import br.com.hubinfo.service.domain.ServiceRequestStatus;
import br.com.hubinfo.service.domain.ServiceType;

import java.time.Instant;
import java.util.UUID;

public interface RequestDteUseCase {

    Result requestFederal(UUID actorUserId, String actorEmail, String cnpj);

    Result requestEstadual(UUID actorUserId, String actorEmail, String cnpj);

    /**
     * Commit 16: inclui captchaChallengeId para o client abrir a janela do hCaptcha.
     */
    record Result(
            UUID requestId,
            ServiceType serviceType,
            ServiceRequestStatus status,
            Instant requestedAt,
            UUID captchaChallengeId
    ) {}
}
