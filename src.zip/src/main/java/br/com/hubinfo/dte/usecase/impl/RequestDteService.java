package br.com.hubinfo.dte.usecase.impl;

import br.com.hubinfo.audit.domain.AuditEventType;
import br.com.hubinfo.audit.usecase.AuditService;
import br.com.hubinfo.captcha.config.HcaptchaChallengeResolver;
import br.com.hubinfo.captcha.usecase.CaptchaChallengeService;
import br.com.hubinfo.dte.usecase.RequestDteUseCase;
import br.com.hubinfo.service.domain.ServiceRequestStatus;
import br.com.hubinfo.service.domain.ServiceType;
import br.com.hubinfo.service.usecase.ServiceRequestRegister;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Solicitação de serviço DT-e.
 *
 * Commit 16:
 * - quando o serviço exigir interação humana, criamos CaptchaChallenge e devolvemos captchaChallengeId
 * - o client abre uma janela com hCaptcha e depois envia o token em /api/v1/captcha/challenges/{id}/solution (ou /solve)
 */
@Service
public class RequestDteService implements RequestDteUseCase {

    private final ServiceRequestRegister serviceRequestRegister;
    private final CaptchaChallengeService captchaChallengeService;
    private final HcaptchaChallengeResolver hcaptchaResolver;
    private final AuditService auditService;

    public RequestDteService(ServiceRequestRegister serviceRequestRegister,
                             CaptchaChallengeService captchaChallengeService,
                             HcaptchaChallengeResolver hcaptchaResolver,
                             AuditService auditService) {
        this.serviceRequestRegister = serviceRequestRegister;
        this.captchaChallengeService = captchaChallengeService;
        this.hcaptchaResolver = hcaptchaResolver;
        this.auditService = auditService;
    }

    @Override
    public Result requestFederal(UUID actorUserId, String actorEmail, String cnpj) {
        return request(ServiceType.DTE_CAIXA_POSTAL_FEDERAL, actorUserId, actorEmail, cnpj);
    }

    @Override
    public Result requestEstadual(UUID actorUserId, String actorEmail, String cnpj) {
        return request(ServiceType.DTE_CAIXA_POSTAL_ESTADUAL, actorUserId, actorEmail, cnpj);
    }

    private Result request(ServiceType type, UUID actorUserId, String actorEmail, String cnpj) {
        // Normaliza CNPJ para somente dígitos (14)
        String cnpjDigits = normalizeCnpj(cnpj);

        Instant now = Instant.now();

        // 1) Registra a solicitação de serviço
        UUID requestId = serviceRequestRegister.register(
                actorUserId,
                actorEmail,
                type,
                Map.of("cnpj", cnpjDigits),
                ServiceRequestStatus.CAPTCHA_REQUIRED,
                now
        );

        // 2) Auditoria (criação da service request)
        auditService.record(
                AuditEventType.SERVICE_REQUEST_CREATED,
                actorUserId,
                actorEmail,
                true,
                "SERVICE_REQUEST",
                requestId,
                Map.of(
                        "serviceType", type.name(),
                        "cnpj", cnpjDigits
                )
        );

        // 3) Se houver config para hCaptcha desse serviço, cria o challenge
        UUID captchaChallengeId = null;

        var challengeCfg = hcaptchaResolver.getOrNull(type);
        if (challengeCfg != null) {
            captchaChallengeId = captchaChallengeService.createForServiceRequest(
                    actorUserId,
                    actorEmail,
                    type,
                    cnpjDigits,
                    requestId,
                    challengeCfg.provider(),
                    challengeCfg.siteKey(),
                    challengeCfg.pageUrl(),
                    challengeCfg.contextKey()
            );
        }

        return new Result(requestId, type, ServiceRequestStatus.CAPTCHA_REQUIRED, now, captchaChallengeId);
    }

    private static String normalizeCnpj(String cnpj) {
        if (cnpj == null) throw new IllegalArgumentException("CNPJ é obrigatório.");

        String digits = cnpj.replaceAll("\\D", "");
        if (digits.length() != 14) {
            throw new IllegalArgumentException("CNPJ inválido. Esperado 14 dígitos. Recebido: " + digits.length());
        }
        return digits;
    }
}
