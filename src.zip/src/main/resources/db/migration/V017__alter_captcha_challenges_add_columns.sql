ALTER TABLE captcha_challenges
    ADD COLUMN cnpj VARCHAR(14) NOT NULL AFTER service_request_id,
    ADD COLUMN context_key VARCHAR(64) NOT NULL AFTER page_url,
    ADD COLUMN created_by_user_id CHAR(36) NULL AFTER solved_at,
    ADD COLUMN created_by_email VARCHAR(255) NULL AFTER created_by_user_id;
